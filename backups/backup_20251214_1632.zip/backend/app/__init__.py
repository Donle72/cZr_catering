"""
App module initialization
"""
