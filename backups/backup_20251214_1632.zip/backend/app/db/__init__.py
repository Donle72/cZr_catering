"""
Database module initialization
"""
