"""
Endpoints module initialization
"""
