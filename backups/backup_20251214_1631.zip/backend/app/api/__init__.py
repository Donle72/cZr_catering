"""
API v1 module initialization
"""
