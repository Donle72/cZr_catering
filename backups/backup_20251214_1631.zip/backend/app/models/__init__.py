"""
Models module initialization
"""
