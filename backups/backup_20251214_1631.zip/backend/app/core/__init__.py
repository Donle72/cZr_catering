"""
Core module initialization
"""
